module.exports = {
    //Informações Gerais
    maxBots: 1,
    totalBots: 0,
    blacklist: false,
    votes: 0,
    botsQueue: "",
    //Informações do bot
    botID: "",
    botLang: "",
    botPrefix: "",
    botDesc: "Nada foi informado.",
    botOwner: "",
    messageID: "",
    //Informações do usuário
    notas: "Nada foi informado.",    
    vip: false,
    coins: 0,
    analises: 0,
    xp: 0,
    reqxp: 700,
    lvl: 1,
    mensagens: 0
}